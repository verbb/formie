import type {
    ScreenshotGlobalProfile,
    ScreenshotPluginBootstrap,
    ScreenshotScenario,
} from './types';

// These helpers are intentionally tiny. They give plugin repos a readable,
// explicit authoring API while keeping the actual runtime wiring in the shared
// CLI package. Scenario files can simply export the result of one of these
// functions, which also makes future validation hooks easy to add here without
// changing every plugin.
export function registerGlobalProfile(profile: ScreenshotGlobalProfile): ScreenshotGlobalProfile {
    return profile;
}

// Plugin bootstrap lives outside the shared package because each Verbb plugin
// needs to seed and configure Craft differently. The shared runtime only knows
// when to call the hook, not what the plugin needs to do.
export function registerPluginBootstrap(bootstrap: ScreenshotPluginBootstrap): ScreenshotPluginBootstrap {
    return bootstrap;
}

// Screenshot scenarios are the smallest authoring unit. They should describe
// "what image do we want?" while presets/bootstrap answer "how does this
// plugin's CP behave?".
export function defineScreenshotScenario(scenario: ScreenshotScenario): ScreenshotScenario {
    return scenario;
}
