import type {
    ScreenshotStep,
    ScreenshotTarget,
    ScreenshotViewport,
} from './types';

// The shared package only ships "shape of screenshot" presets. Anything that
// knows about a specific plugin's DOM quirks belongs in that plugin's local
// `.screenshots` layer, where it can wrap these base presets.
type CpFocusedRegionOptions = {
    selector?: string;
    viewport?: ScreenshotViewport;
    padding?: NonNullable<Extract<ScreenshotTarget, { type: 'selector' }>['padding']>;
};

type CpFullScreenOptions = {
    viewport?: ScreenshotViewport;
};

type CpModalOptions = {
    viewport?: ScreenshotViewport;
    selector?: string;
    padding?: NonNullable<Extract<ScreenshotTarget, { type: 'selector' }>['padding']>;
};

type CpDetailViewOptions = {
    viewport?: ScreenshotViewport;
    selector?: string;
    padding?: NonNullable<Extract<ScreenshotTarget, { type: 'selector' }>['padding']>;
};

const defaultFocusedViewport: ScreenshotViewport = {
    width: 1054,
    height: 716,
    deviceScaleFactor: 2,
};

// Focused screenshots are the default docs shape for our plugin docs. They are
// generally smaller, more compositional crops of the CP instead of full-page
// dumps, so the defaults bias toward a moderate viewport with a little extra
// breathing room around the target element.
const defaultFocusedPadding = {
    top: 0,
    right: 24,
    bottom: 24,
    left: 24,
};

export function createCpFocusedRegionPreset(options: CpFocusedRegionOptions = {}) {
    return {
        viewport: options.viewport ?? defaultFocusedViewport,
        steps: [
            // A small settle wait makes screenshots more deterministic across
            // heavy CP screens that hydrate after the initial document paint.
            { type: 'wait', waitFor: { type: 'timeout', ms: 500 } as const },
        ] satisfies ScreenshotStep[],
        target: {
            type: 'selector',
            selector: options.selector ?? '#content',
            padding: options.padding ?? defaultFocusedPadding,
        } satisfies ScreenshotTarget,
    };
}

export function createCpFullScreenPreset(options: CpFullScreenOptions = {}) {
    return {
        viewport: options.viewport ?? defaultFocusedViewport,
        steps: [
            // Full-screen captures still benefit from the same light settle
            // wait, even though they do not depend on a specific selector.
            { type: 'wait', waitFor: { type: 'timeout', ms: 500 } as const },
        ] satisfies ScreenshotStep[],
        target: {
            type: 'page',
            fullPage: false,
        } satisfies ScreenshotTarget,
    };
}

export function createCpModalPreset(options: CpModalOptions = {}) {
    return {
        // Modals usually need a larger viewport so the dialog fits without any
        // extra scaling or screenshot-specific zoom tricks.
        viewport: options.viewport ?? {
            width: 1280,
            height: 900,
            deviceScaleFactor: 2,
        },
        target: {
            type: 'selector',
            selector: options.selector ?? '[role="dialog"]',
            padding: options.padding ?? {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0,
            },
        } satisfies ScreenshotTarget,
    };
}

export function createCpDetailViewPreset(options: CpDetailViewOptions = {}) {
    return {
        viewport: options.viewport ?? {
            width: 1762,
            height: 916,
            deviceScaleFactor: 2,
        },
        steps: [
            // Detail views tend to have server-rendered content plus a sidebar
            // or preview pane, so we keep the same lightweight settle wait.
            { type: 'wait', waitFor: { type: 'timeout', ms: 500 } as const },
        ] satisfies ScreenshotStep[],
        target: {
            type: 'selector',
            selector: options.selector ?? '#content',
            padding: options.padding ?? {
                top: 24,
                right: 24,
                bottom: 24,
                left: 24,
            },
        } satisfies ScreenshotTarget,
    };
}
