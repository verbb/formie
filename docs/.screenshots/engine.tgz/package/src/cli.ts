import fs from 'node:fs/promises';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';
import { chromium, type Browser, type Page } from 'playwright';

import type {
    ScreenshotGlobalProfile,
    ScreenshotPluginBootstrap,
    ScreenshotScenario,
    ScreenshotSetupContext,
    ScreenshotStep,
    ScreenshotTarget,
    WaitForSpec,
} from './types';

// The CLI keeps runtime concerns in one place: discover plugin docs config,
// prepare a disposable Craft install, run scenario setup, and then hand the
// browser a deterministic page state for either preview or capture.
type LoadedScenario = {
    filePath: string;
    scenario: ScreenshotScenario;
};

type CliCommand = 'capture' | 'prepare' | 'preview';

type CliOptions = {
    command: CliCommand;
    filter?: string;
    changed: boolean;
    debug: boolean;
    keepInstall: boolean;
    headed: boolean;
    inspect: boolean;
    saveFromPreview: boolean;
    reuseInstall?: string;
};

type ScreenshotDatabaseConfig = {
    driver: 'mysql' | 'pgsql';
    server: string;
    port: string;
    user: string;
    password: string;
    schema: string;
    unixSocket?: string;
    databaseNamePrefix: string;
};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
function resolvePluginRoot(docsRootPath: string): string {
    const override = process.env.CRAFT_SCREENSHOT_PLUGIN_ROOT?.trim();

    if (override) {
        const resolved = path.isAbsolute(override)
            ? override
            : path.resolve(docsRootPath, override);

        if (!fileExistsSync(path.join(resolved, 'composer.json'))) {
            throw new Error(`CRAFT_SCREENSHOT_PLUGIN_ROOT does not contain composer.json: ${resolved}`);
        }

        return resolved;
    }

    return path.resolve(docsRootPath, '..');
}

const docsRoot = resolveDocsRoot();
const pluginRoot = resolvePluginRoot(docsRoot);

const screenshotConfigRoot = path.join(docsRoot, '.screenshots');
// Campaign recipes can declare additional plugin sources without mounting an entire workspace.
const sourcesPath = path.join(screenshotConfigRoot, 'sources.json');
const captureSources: { name: string; path: string }[] = existsSync(sourcesPath)
    ? JSON.parse(readFileSync(sourcesPath, 'utf8')) : [];
for (const source of captureSources) {
    if (!/^[a-z][a-z0-9-]+$/.test(source.name)) throw new Error('Invalid capture source name.');
    source.path = path.resolve(docsRoot, source.path);
    if (!existsSync(path.join(source.path, 'composer.json'))) throw new Error(`Missing capture source: ${source.path}`);
}
if (new Set(captureSources.map(source => source.name)).size !== captureSources.length) throw new Error('Duplicate capture source name.');
const outputRoot = path.join(docsRoot, '_screenshots');
const tempRootBase = path.join(pluginRoot, '.cache', 'docs-screenshots', process.env.CRAFT_SCREENSHOT_PROJECT ?? 'docs');
const baseInstallCacheRoot = path.join(tempRootBase, 'base-installs');
const lastPreparedInstallPath = path.join(tempRootBase, 'last-prepare.json');

const screenshotEngineLayoutVersion = '4-ddev';

// Bump this when the shared package changes its cache/runtime expectations in a
// way that makes old prepared installs unsafe to reuse. That lets us invalidate
// stale cached installs without asking every plugin author to manually clear
// `.cache/docs-screenshots`.

type RuntimeCommandOptions = {
    cwd?: string;
    allowFailure?: boolean;
    env?: NodeJS.ProcessEnv;
};

type RuntimeServerHandle = {
    stop(): Promise<void>;
};

type ScreenshotRuntime = {
    name: 'ddev';
    setup(): Promise<string>;
    teardown(options: { keepRuntime: boolean }): Promise<void>;
    prepareCraftInstall(options: {
        installDir: string;
        pluginMeta: { packageName: string; handle: string };
        debug: boolean;
    }): Promise<void>;
    runPhpCommand(args: string[], options?: RuntimeCommandOptions): Promise<string>;
    runComposerCommand(args: string[], options?: RuntimeCommandOptions): Promise<string>;
    createDatabase(config: ScreenshotDatabaseConfig, databaseName: string): Promise<void>;
    dropDatabase(config: ScreenshotDatabaseConfig, databaseName: string): Promise<void>;
    startPhpServer(installDir: string, baseUrl: string): Promise<RuntimeServerHandle>;
};

function directoryExistsSync(targetPath: string): boolean {
    return existsSync(targetPath);
}

function fileExistsSync(targetPath: string): boolean {
    return existsSync(targetPath);
}

function resolveDocsRoot(): string {
    // The CLI is intentionally forgiving about where it is launched from. In
    // practice it is often invoked from a plugin repo root, a docs directory,
    // or an npm script whose cwd is different again.
    const candidates = [
        process.cwd(),
        process.env.INIT_CWD,
        process.env.npm_config_local_prefix,
    ].filter((value): value is string => Boolean(value));

    for (const candidate of candidates) {
        const resolved = findDocsRoot(candidate);

        if (resolved) {
            return resolved;
        }
    }

    throw new Error('Unable to resolve docs root. Run the screenshot CLI from a plugin docs directory or a repo that contains docs/.screenshots.');
}

function findDocsRoot(startPath: string): string | null {
    let current = path.resolve(startPath);

    while (true) {
        const directDocsRoot = path.join(current, '.screenshots');
        const nestedDocsRoot = path.join(current, 'docs', '.screenshots');

        if (directoryExistsSync(directDocsRoot)) {
            return current;
        }

        if (directoryExistsSync(nestedDocsRoot)) {
            return path.join(current, 'docs');
        }

        const parent = path.dirname(current);

        if (parent === current) {
            return null;
        }

        current = parent;
    }
}

async function main(): Promise<void> {
    const options = parseArgs(process.argv.slice(2));
    const pluginMeta = await readPluginMetadata();
    const globalProfile = await loadGlobalProfile();
    const pluginBootstrap = await loadPluginBootstrap();

    if (options.command === 'prepare') {
        await prepareInstall({ options, pluginMeta });
        return;
    }

    const scenarios = await loadScenarios(options);

    if (!scenarios.length) {
        console.log('No screenshot scenarios matched the current filters.');
        return;
    }

    if (options.command === 'preview' && scenarios.length !== 1) {
        throw new Error('Preview mode requires exactly one matched scenario. Use --filter or --preview <id>.');
    }

    const resolvedInstall = await resolveInstallReuse(options.reuseInstall, pluginMeta);
    const runId = 'runtime';
    const tempRoot = resolvedInstall?.tempRoot ?? path.join(tempRootBase, createRuntimeProjectName(pluginMeta.handle, runId));
    const installDir = resolvedInstall?.installDir ?? path.join(tempRoot, 'craft-app');
    let baseUrl = `http://${createRuntimeProjectName(pluginMeta.handle, runId)}.ddev.site`;
    const runtimeProjectName = resolvedInstall?.runtimeProjectName ?? createRuntimeProjectName(pluginMeta.handle, runId);
    const runtime = createDdevRuntime({ baseUrl, tempRoot, runId, pluginMeta, runtimeProjectName });
    const databaseConfig = readDatabaseConfig();
    const keepArtifacts = options.debug || options.keepInstall || options.command === 'preview' || Boolean(options.reuseInstall);

    await fs.mkdir(tempRoot, { recursive: true });
    await fs.mkdir(outputRoot, { recursive: true });

    let runtimeReady = false;
    let failed = false;
    try {
        console.log(resolvedInstall ? `Reusing Craft install at ${installDir}` : 'Preparing screenshot runtime...');
        baseUrl = await runtime.setup();
        runtimeReady = true;
        console.log(`Using runtime ${runtimeProjectName} on ${baseUrl}`);

        if (!resolvedInstall) {
            await runtime.prepareCraftInstall({ installDir, pluginMeta, debug: options.debug });
        }

        for (const loadedScenario of scenarios) {
            const verb = options.command === 'preview' ? 'Previewing' : 'Generating';
            console.log(`${verb} screenshot: ${loadedScenario.scenario.id}`);

            await generateScenario({
                installDir,
                tempRoot,
                outputRoot,
                docsRoot,
                pluginRoot,
                pluginMeta,
                globalProfile,
                pluginBootstrap,
                loadedScenario,
                databaseConfig,
                baseUrl,
                runtime,
                debug: options.debug,
                keepInstall: keepArtifacts,
                command: options.command,
                headed: options.headed,
                inspect: options.inspect,
                saveFromPreview: options.saveFromPreview,
            });
        }
        await fs.writeFile(path.join(tempRoot, 'result.json'), JSON.stringify({ status: 'passed', scenarios: scenarios.map(item => item.scenario.id), finishedAt: new Date().toISOString() }, null, 2));
    } catch (error) {
        failed = true;
        if (runtimeReady) await fs.writeFile(path.join(tempRoot, 'result.json'), JSON.stringify({ status: 'failed', message: String(error), finishedAt: new Date().toISOString() }, null, 2));
        throw error;
    } finally {
        await runtime.teardown({ keepRuntime: keepArtifacts && !failed });

        if (runtimeReady && (keepArtifacts || failed)) {
            await writeLastPreparedInstall({ installDir, tempRoot, baseUrl, runtimeProjectName, runtimeRunId: runId });
            console.log(`Keeping temporary Craft install at ${installDir}`);
        } else if (runtimeReady) {
            await fs.rm(installDir, { recursive: true, force: true });
        }
    }
}

function parseArgs(args: string[]): CliOptions {
    const options: CliOptions = {
        command: 'capture',
        changed: false,
        debug: false,
        keepInstall: false,
        headed: false,
        inspect: false,
        saveFromPreview: false,
    };

    for (let index = 0; index < args.length; index += 1) {
        const arg = args[index];

        if (arg === 'prepare' || arg === 'capture' || arg === 'preview') {
            options.command = arg;

            if (arg === 'preview') {
                options.headed = true;
                options.keepInstall = true;
            }

            continue;
        }

        if (arg === 'inspect') {
            options.command = 'preview';
            options.headed = true;
            options.inspect = true;
            options.keepInstall = true;
            options.filter = args[index + 1];
            index += 1;
            continue;
        }

        if (arg === '--changed') {
            options.changed = true;
            continue;
        }

        if (arg === '--debug') {
            options.debug = true;
            continue;
        }

        if (arg === '--keep-install') {
            options.keepInstall = true;
            continue;
        }

        if (arg === '--headed') {
            options.headed = true;
            continue;
        }

        if (arg === '--save-from-preview') {
            options.saveFromPreview = true;
            continue;
        }

        if (arg === '--reuse-install') {
            options.reuseInstall = args[index + 1];
            index += 1;
            continue;
        }

        if (arg === '--preview') {
            options.command = 'preview';
            options.headed = true;
            options.keepInstall = true;
            options.filter = args[index + 1];
            index += 1;
            continue;
        }

        if (arg === '--inspect') {
            options.command = 'preview';
            options.headed = true;
            options.inspect = true;
            options.keepInstall = true;
            options.filter = args[index + 1];
            index += 1;
            continue;
        }

        if (arg === '--filter') {
            options.filter = args[index + 1];
            index += 1;
            continue;
        }

        throw new Error(`Unknown argument: ${arg}`);
    }

    return options;
}

async function readPluginMetadata(): Promise<{ packageName: string; handle: string; className?: string }> {
    const composerJsonPath = path.join(pluginRoot, 'composer.json');
    const composerJson = JSON.parse(await fs.readFile(composerJsonPath, 'utf8')) as {
        name?: string;
        extra?: {
            handle?: string;
            class?: string;
        };
    };

    if (!composerJson.name || !composerJson.extra?.handle) {
        throw new Error(`Unable to infer plugin metadata from ${composerJsonPath}.`);
    }

    return {
        packageName: composerJson.name,
        handle: composerJson.extra.handle,
        className: composerJson.extra.class,
    };
}

async function loadGlobalProfile(): Promise<ScreenshotGlobalProfile> {
    const filePath = path.join(screenshotConfigRoot, 'global.profile.ts');
    const imported = await importModule<ScreenshotGlobalProfile>(filePath);
    return imported;
}

async function loadPluginBootstrap(): Promise<ScreenshotPluginBootstrap | null> {
    const filePath = path.join(screenshotConfigRoot, 'plugin.bootstrap.ts');

    try {
        return await importModule<ScreenshotPluginBootstrap>(filePath);
    } catch (error) {
        if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
            return null;
        }

        throw error;
    }
}

async function loadScenarios(options: CliOptions): Promise<LoadedScenario[]> {
    const files = await discoverScenarioFiles(docsRoot);
    const selectedFiles = await filterScenarioFiles(files, options);
    const scenarios: LoadedScenario[] = [];

    for (const filePath of selectedFiles) {
        const scenario = await importModule<ScreenshotScenario>(filePath);
        scenarios.push({ filePath, scenario });
    }

    return scenarios.sort((left, right) => left.scenario.id.localeCompare(right.scenario.id));
}

async function prepareInstall({
    options,
    pluginMeta,
}: {
    options: CliOptions;
    pluginMeta: { packageName: string; handle: string };
}): Promise<void> {
    // `prepare` exists purely to shorten the authoring loop. It creates a
    // fully installed Craft app once, then later preview/capture runs can reuse
    // that install instead of paying the install/bootstrap cost every time.
    const runId = 'runtime';
    const tempRoot = path.join(tempRootBase, createRuntimeProjectName(pluginMeta.handle, runId));
    const installDir = path.join(tempRoot, 'craft-app');
    let baseUrl = `http://${createRuntimeProjectName(pluginMeta.handle, runId)}.ddev.site`;
    const runtimeProjectName = createRuntimeProjectName(pluginMeta.handle, runId);
    const runtime = createDdevRuntime({ baseUrl, tempRoot, runId, pluginMeta, runtimeProjectName });

    await fs.mkdir(tempRoot, { recursive: true });

    try {
        console.log(`Preparing screenshot runtime ${runtimeProjectName} on ${baseUrl}`);
        baseUrl = await runtime.setup();
        await runtime.prepareCraftInstall({ installDir, pluginMeta, debug: options.debug });
        await writeLastPreparedInstall({ installDir, tempRoot, baseUrl, runtimeProjectName, runtimeRunId: runId });
        console.log(`Prepared reusable Craft install at ${installDir}`);
        console.log(`Reuse it with: npm run docs:screenshots -- preview --reuse-install last --filter <scenario>`);
    } finally {
        await runtime.teardown({ keepRuntime: false });
    }
}

async function resolveInstallReuse(
    reuseInstall: string | undefined,
    pluginMeta: { handle: string },
): Promise<{ installDir: string; tempRoot: string; baseUrl?: string; runtimeProjectName?: string; runtimeRunId?: string } | null> {
    if (!reuseInstall) {
        return null;
    }

    let installPath = reuseInstall;

    if (reuseInstall === 'last') {
        const lastPrepared = JSON.parse(await fs.readFile(lastPreparedInstallPath, 'utf8')) as {
            installDir: string;
            tempRoot: string;
            baseUrl?: string;
            runtimeProjectName?: string;
            runtimeRunId?: string;
            engineLayoutVersion?: string;
        };

        if (lastPrepared.engineLayoutVersion !== screenshotEngineLayoutVersion) {
            return null;
        }

        return {
            ...lastPrepared,
            baseUrl: lastPrepared.baseUrl ?? await inferReuseBaseUrl(lastPrepared.tempRoot),
            runtimeProjectName: lastPrepared.runtimeProjectName ?? createRuntimeProjectName(pluginMeta.handle, lastPrepared.runtimeRunId ?? path.basename(lastPrepared.tempRoot)),
            runtimeRunId: lastPrepared.runtimeRunId ?? path.basename(lastPrepared.tempRoot),
        };
    }

    if (!path.isAbsolute(installPath)) {
        installPath = path.resolve(pluginRoot, installPath);
    }

    const stats = await fs.stat(installPath);
    const installDir = stats.isDirectory() && path.basename(installPath) === 'craft-app'
        ? installPath
        : path.join(installPath, 'craft-app');

    if (!await fileExists(path.join(installDir, 'vendor', 'autoload.php'))) {
        throw new Error(`Unable to find a prepared Craft install at ${installDir}.`);
    }

    return {
        installDir,
        tempRoot: path.dirname(installDir),
        baseUrl: await inferReuseBaseUrl(path.dirname(installDir)),
        runtimeProjectName: createRuntimeProjectName(pluginMeta.handle, path.basename(path.dirname(installDir))),
        runtimeRunId: path.basename(path.dirname(installDir)),
    };
}

async function writeLastPreparedInstall({
    installDir,
    tempRoot,
    baseUrl,
    runtimeProjectName,
    runtimeRunId,
}: {
    installDir: string;
    tempRoot: string;
    baseUrl?: string;
    runtimeProjectName?: string;
    runtimeRunId?: string;
}): Promise<void> {
    await fs.mkdir(tempRootBase, { recursive: true });
    await fs.writeFile(lastPreparedInstallPath, `${JSON.stringify({
        installDir,
        tempRoot,
        baseUrl,
        runtimeProjectName,
        runtimeRunId,
        engineLayoutVersion: screenshotEngineLayoutVersion,
        updatedAt: new Date().toISOString(),
    }, null, 2)}\n`);
}

function createRuntimeProjectName(pluginHandle: string, _runId: string): string {
    const name = process.env.CRAFT_SCREENSHOT_PROJECT ?? `${pluginHandle}-docs`;
    if (!/^[a-z][a-z0-9-]{2,47}$/.test(name)) {
        throw new Error('Screenshot project names must be 3–48 lowercase letters, digits or hyphens.');
    }
    return name;
}

async function inferReuseBaseUrl(_tempRoot: string): Promise<string | undefined> {
    return undefined;
}


async function discoverScenarioFiles(root: string): Promise<string[]> {
    const files: string[] = [];

    async function walk(currentPath: string): Promise<void> {
        const entries = await fs.readdir(currentPath, { withFileTypes: true });

        for (const entry of entries) {
            if (entry.name === 'node_modules' || entry.name === '.vitepress' || entry.name === '_screenshots') {
                continue;
            }

            const nextPath = path.join(currentPath, entry.name);

            if (entry.isDirectory()) {
                await walk(nextPath);
                continue;
            }

            if (entry.isFile() && /\.screenshot\.(ts|js|mjs)$/.test(entry.name)) {
                files.push(nextPath);
            }
        }
    }

    await walk(root);
    return files;
}

async function filterScenarioFiles(files: string[], options: CliOptions): Promise<string[]> {
    let selected = [...files];

    if (options.changed) {
        const changedFilesOutput = await runCommand('git', ['diff', '--name-only', 'HEAD', '--', docsRoot], {
            cwd: pluginRoot,
            allowFailure: true,
        });

        const changedFiles = new Set(changedFilesOutput
            .split('\n')
            .map(line => line.trim())
            .filter(Boolean)
            .map(line => path.resolve(pluginRoot, line)));

        selected = selected.filter(filePath => changedFiles.has(filePath));
    }

    if (options.filter) {
        const filterNeedle = options.filter.toLowerCase();
        selected = selected.filter(filePath => {
            const relativePath = path.relative(docsRoot, filePath).toLowerCase();
            return relativePath.includes(filterNeedle);
        });
    }

    return selected;
}

async function generateScenario({
    installDir,
    tempRoot,
    outputRoot,
    docsRoot: scenarioDocsRoot,
    pluginRoot: scenarioPluginRoot,
    pluginMeta,
    globalProfile,
    pluginBootstrap,
    loadedScenario,
    databaseConfig,
    baseUrl,
    runtime,
    debug,
    keepInstall,
    command,
    headed,
    inspect,
    saveFromPreview,
}: {
    installDir: string;
    tempRoot: string;
    outputRoot: string;
    docsRoot: string;
    pluginRoot: string;
    pluginMeta: { packageName: string; handle: string; className?: string };
    globalProfile: ScreenshotGlobalProfile;
    pluginBootstrap: ScreenshotPluginBootstrap | null;
    loadedScenario: LoadedScenario;
    databaseConfig: ScreenshotDatabaseConfig;
    baseUrl: string;
    runtime: ScreenshotRuntime;
    debug: boolean;
    keepInstall: boolean;
    command: CliCommand;
    headed: boolean;
    inspect: boolean;
    saveFromPreview: boolean;
}): Promise<void> {
    // Rebuild the same owned database and app for every scenario. Only dependencies are reused.
    const { scenario } = loadedScenario;
    const scenarioTempRoot = path.join(tempRoot, scenario.id);
    const envPath = path.join(installDir, '.env');
    const databaseName = 'db';
    const profile = scenario.globalProfile && scenario.globalProfile !== globalProfile.id
        ? globalProfile
        : globalProfile;

    await fs.mkdir(scenarioTempRoot, { recursive: true });
    await runtime.prepareCraftInstall({ installDir, pluginMeta, debug });
    await runtime.createDatabase(databaseConfig, databaseName);
    await writeDotEnv({
        envPath,
        baseUrl,
        profile,
        databaseConfig,
        databaseName,
    });

    let server: RuntimeServerHandle | null = null;
    let browser: Browser | null = null;

    try {
        await runtime.runPhpCommand(['craft', 'install', '--interactive=0', `--username=${profile.admin.username}`, `--email=${profile.admin.email ?? 'admin@example.test'}`, `--password=${profile.admin.password}`, `--site-name=${profile.siteName}`, `--site-url=${baseUrl}`, `--language=${profile.language ?? 'en-US'}`], {
            cwd: installDir,
        });

        const context = createSetupContext({
            docsRoot: scenarioDocsRoot,
            pluginRoot: scenarioPluginRoot,
            installDir,
            outputRoot,
            tempRoot: scenarioTempRoot,
            baseUrl,
            profile,
            pluginMeta,
            runtime,
        });

        await context.installAndEnablePlugin();

        if (pluginBootstrap?.setup) {
            await pluginBootstrap.setup(context);
        }

        if (scenario.setup) {
            await scenario.setup(context);
        }

        server = await runtime.startPhpServer(installDir, baseUrl);

        browser = await chromium.launch({
            headless: !(debug || headed || command === 'preview'),
        });

        const viewport = scenario.viewport ?? profile.viewport;
        const page = await browser.newPage({
            locale: profile.locale ?? 'en-AU',
            colorScheme: profile.colorScheme ?? 'light',
            timezoneId: profile.timezone ?? 'Australia/Melbourne',
            viewport: {
                width: viewport.width,
                height: viewport.height,
            },
            deviceScaleFactor: viewport.deviceScaleFactor ?? 1,
        });

        if (inspect || debug) {
            page.on('console', (message) => {
                console.log(`[browser:${message.type()}] ${message.text()}`);
            });
            page.on('response', (response) => {
                if (response.status() >= 400) {
                    console.log(`[browser:http ${response.status()}] ${response.url()}`);
                }
            });
        }

        if (command === 'preview' || inspect) {
            // Preview should show the final framed state, not every intermediate
            // layout jump while Craft/plugin UI hydrate. We briefly mask the page,
            // run all setup work, then reveal it once the target is stable.
            await page.addInitScript(() => {
                const style = document.createElement('style');
                style.dataset.verbbDocsScreenshotPreviewMask = 'true';
                style.textContent = `
                    html, body {
                        opacity: 0 !important;
                    }
                `;
                document.documentElement.appendChild(style);
            });
        }

        const scenarioRoute = await resolveScenarioRoute(scenario, context);

        await loginToCp(page, baseUrl, profile);
        await page.goto(new URL(scenarioRoute, baseUrl).toString(), { waitUntil: 'domcontentloaded' });
        await applyDeterministicPageStyling(page);
        for (const step of scenario.preSteps ?? []) {
            await runStep(page, step);
        }
        await waitForSpec(page, { type: 'loadState', state: 'networkidle' });

        const waits = Array.isArray(scenario.waitFor) ? scenario.waitFor : scenario.waitFor ? [scenario.waitFor] : [];
        for (const wait of waits) {
            await waitForSpec(page, wait);
        }

        for (const step of scenario.steps ?? []) {
            await runStep(page, step);
        }

        const outputPath = path.join(scenarioDocsRoot, scenario.output);
        await fs.mkdir(path.dirname(outputPath), { recursive: true });

        if (command === 'preview') {
            await stabilizeTargetForMeasurement(page, scenario.target);
            await showPreviewOverlay(page, scenario.target);
            await revealPreviewPage(page);

            if (saveFromPreview) {
                await captureTarget(page, outputPath, scenario.target);
                console.log(`Saved preview capture to ${outputPath}`);
            }

            if (inspect) {
                await page.pause();
            } else {
                console.log('Preview ready. Close the browser window when you are done.');
                await waitForBrowserClose(browser);
            }

            return;
        }

        await captureTarget(page, outputPath, scenario.target);
    } finally {
        if (browser) {
            await browser.close();
        }

        if (server) {
            await server.stop();
        }

        if (!debug && !keepInstall) {
            await runtime.dropDatabase(databaseConfig, databaseName);
        }
    }
}

async function resolveScenarioRoute(scenario: ScreenshotScenario, context: ScreenshotSetupContext): Promise<string> {
    if (typeof scenario.route === 'function') {
        return scenario.route(context);
    }

    return scenario.route;
}

function createSetupContext({
    docsRoot: currentDocsRoot,
    pluginRoot: currentPluginRoot,
    installDir,
    outputRoot: currentOutputRoot,
    tempRoot,
    baseUrl,
    profile,
    pluginMeta,
    runtime,
}: {
    docsRoot: string;
    pluginRoot: string;
    installDir: string;
    outputRoot: string;
    tempRoot: string;
    baseUrl: string;
    profile: ScreenshotGlobalProfile;
    pluginMeta: { packageName: string; handle: string; className?: string };
    runtime: ScreenshotRuntime;
}): ScreenshotSetupContext {
    return {
        docsRoot: currentDocsRoot,
        pluginRoot: currentPluginRoot,
        installDir,
        outputRoot: currentOutputRoot,
        tempRoot,
        baseUrl,
        profile,
        plugin: pluginMeta,
        toRuntimePath(targetPath: string) {
            return runtime.name === 'ddev'
                ? hostPathToContainerPath(targetPath)
                : targetPath;
        },
        async run(command: string, args: string[] = [], options: RuntimeCommandOptions = {}) {
            return runCommand(command, args, {
                cwd: options.cwd ?? installDir,
                allowFailure: options.allowFailure,
                env: options.env,
            });
        },
        async runCraft(args: string[], options: Omit<RuntimeCommandOptions, 'cwd'> = {}) {
            const resolvedArgs = runtime.name === 'ddev'
                ? args.map((arg) => mapCommandArgumentForRuntime(arg))
                : args;

            return runtime.runPhpCommand(['craft', ...resolvedArgs], {
                cwd: installDir,
                allowFailure: options.allowFailure,
                env: options.env,
            });
        },
        async runCraftScript(php: string, options: { allowFailure?: boolean; label?: string } = {}) {
            // Scripts are the cleanest way for plugin fixtures to interact with
            // Craft services/models without trying to squeeze complex setup into
            // shell commands. We generate a one-off bootstrap file inside the
            // scenario temp dir, run it, then let the temp dir disappear later.
            const scriptPath = path.join(tempRoot, `${options.label ?? 'craft-task'}-${crypto.randomBytes(3).toString('hex')}.php`);
            const runtimeInstallDir = runtime.name === 'ddev'
                ? hostPathToContainerPath(installDir)
                : installDir;
            const bootstrap = `<?php
declare(strict_types=1);

require ${JSON.stringify(path.join(runtimeInstallDir, 'vendor/autoload.php'))};
defined('CRAFT_BASE_PATH') || define('CRAFT_BASE_PATH', ${JSON.stringify(runtimeInstallDir)});
defined('CRAFT_VENDOR_PATH') || define('CRAFT_VENDOR_PATH', CRAFT_BASE_PATH . '/vendor');
defined('CRAFT_CONFIG_PATH') || define('CRAFT_CONFIG_PATH', CRAFT_BASE_PATH . '/config');
defined('CRAFT_STORAGE_PATH') || define('CRAFT_STORAGE_PATH', CRAFT_BASE_PATH . '/storage');
defined('CRAFT_TEMPLATES_PATH') || define('CRAFT_TEMPLATES_PATH', CRAFT_BASE_PATH . '/templates');

$app = require CRAFT_VENDOR_PATH . '/craftcms/cms/bootstrap/console.php';
${php}
`;

            await fs.writeFile(scriptPath, bootstrap);

            const envFromFile = await readEnvFile(path.join(installDir, '.env'));
            return runtime.runPhpCommand([scriptPath], {
                cwd: installDir,
                allowFailure: options.allowFailure,
                env: envFromFile,
            });
        },
        async installAndEnablePlugin() {
            // Craft's install/enable commands are idempotent enough for our
            // workflow, but we still inspect their output because they can fail
            // "successfully" from the shell's perspective while printing a real
            // Craft error message.
            const installOutput = await this.runCraft(['plugin/install', pluginMeta.handle, '--interactive=0'], {
                allowFailure: true,
            });

            if (containsCraftCommandError(installOutput)) {
                throw new Error(`Unable to install plugin ${pluginMeta.handle}: ${installOutput}`);
            }

            const enableOutput = await this.runCraft(['plugin/enable', pluginMeta.handle, '--interactive=0'], {
                allowFailure: true,
            });

            if (containsCraftCommandError(enableOutput)) {
                throw new Error(`Unable to enable plugin ${pluginMeta.handle}: ${enableOutput}`);
            }
        },
    };
}

function containsCraftCommandError(output: string): boolean {
    if (!output.trim()) {
        return false;
    }

    return /(exception '|error:|fatal error|stack trace:|unable to|sqlstate\[)/i.test(output);
}

async function readEnvFile(filePath: string): Promise<NodeJS.ProcessEnv> {
    try {
        const contents = await fs.readFile(filePath, 'utf8');
        const env: NodeJS.ProcessEnv = {};

        for (const rawLine of contents.split(/\r?\n/)) {
            const line = rawLine.trim();

            if (!line || line.startsWith('#')) {
                continue;
            }

            const separatorIndex = line.indexOf('=');

            if (separatorIndex === -1) {
                continue;
            }

            const key = line.slice(0, separatorIndex).trim();
            let value = line.slice(separatorIndex + 1).trim();

            if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith('\'') && value.endsWith('\''))) {
                value = value.slice(1, -1);
            }

            env[key] = value;
        }

        return env;
    } catch (error) {
        if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
            return {};
        }

        throw error;
    }
}

async function writeDotEnv({
    envPath,
    baseUrl,
    profile,
    databaseConfig,
    databaseName,
}: {
    envPath: string;
    baseUrl: string;
    profile: ScreenshotGlobalProfile;
    databaseConfig: ScreenshotDatabaseConfig;
    databaseName: string;
}): Promise<void> {
    const contents = [
        `CRAFT_APP_ID="CraftCMS--${crypto.randomUUID()}"`,
        'CRAFT_ENVIRONMENT="dev"',
        `CRAFT_SECURITY_KEY="${crypto.randomBytes(24).toString('hex')}"`,
        'CRAFT_DEV_MODE="true"',
        'CRAFT_ALLOW_ADMIN_CHANGES="true"',
        'CRAFT_DISALLOW_ROBOTS="true"',
        `CRAFT_DB_DRIVER="${databaseConfig.driver}"`,
        `CRAFT_DB_SERVER="${databaseConfig.server}"`,
        `CRAFT_DB_PORT="${databaseConfig.port}"`,
        `CRAFT_DB_USER="${databaseConfig.user}"`,
        `CRAFT_DB_PASSWORD="${databaseConfig.password}"`,
        `CRAFT_DB_DATABASE="${databaseName}"`,
        `CRAFT_DB_SCHEMA="${databaseConfig.schema}"`,
        'CRAFT_DB_TABLE_PREFIX=""',
        `CRAFT_DB_UNIX_SOCKET="${databaseConfig.unixSocket ?? ''}"`,
        `PRIMARY_SITE_URL="${baseUrl}/"`,
        `DEFAULT_SITE_NAME="${profile.siteName}"`,
        '',
    ].join('\n');

    await fs.writeFile(envPath, contents);
}

function readDatabaseConfig(): ScreenshotDatabaseConfig {
    // Only the dedicated DDEV database is a reset target. Never accept external credentials.
    return { driver: 'mysql', server: 'db', port: '3306', user: 'root', password: 'root', schema: 'public', databaseNamePrefix: 'docs_shot_' };
}

function createDatabasePhp(config: ScreenshotDatabaseConfig, databaseName: string, create: boolean): string {
    if (databaseName !== 'db' || config.server !== 'db') throw new Error('Refusing a foreign screenshot database.');
    const payload = JSON.stringify({
        ...config,
        databaseName,
        create,
    });

    return `
$config = json_decode(${JSON.stringify(payload)}, true, 512, JSON_THROW_ON_ERROR);
$driver = $config['driver'];
$databaseName = $config['databaseName'];
$create = (bool)$config['create'];
$user = $config['user'];
$password = $config['password'];

if ($driver === 'mysql') {
    $dsn = !empty($config['unixSocket'])
        ? 'mysql:unix_socket=' . $config['unixSocket']
        : 'mysql:host=' . $config['server'] . ';port=' . $config['port'];

    $pdo = new PDO($dsn, $user, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);

    $quotedName = '\`' . str_replace('\`', '\`\`', $databaseName) . '\`';

    if ($create) {
        $pdo->exec('DROP DATABASE IF EXISTS ' . $quotedName);
        $pdo->exec('CREATE DATABASE ' . $quotedName . ' CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    } else {
        $pdo->exec('DROP DATABASE IF EXISTS ' . $quotedName);
    }
    return;
}

$dsn = 'pgsql:host=' . $config['server'] . ';port=' . $config['port'] . ';dbname=postgres';
$pdo = new PDO($dsn, $user, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
]);
$quotedName = '"' . str_replace('"', '""', $databaseName) . '"';

if ($create) {
    $pdo->exec('SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = ' . $pdo->quote($databaseName));
    $pdo->exec('DROP DATABASE IF EXISTS ' . $quotedName);
    $pdo->exec('CREATE DATABASE ' . $quotedName);
} else {
    $pdo->exec('SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = ' . $pdo->quote($databaseName));
    $pdo->exec('DROP DATABASE IF EXISTS ' . $quotedName);
}
`;
}

function createDdevRuntime({ baseUrl, tempRoot, runtimeProjectName }: {
    baseUrl: string;
    tempRoot: string;
    runId: string;
    pluginMeta: { packageName: string; handle: string };
    runtimeProjectName: string;
}): ScreenshotRuntime {
    let locked = false;
    let started = false;
    const lockPath = path.join(tempRoot, 'run.lock');
    const command = (args: string[], options: RuntimeCommandOptions = {}) => runCommand('ddev', args, {
        cwd: tempRoot, env: process.env, allowFailure: options.allowFailure,
    });
    const execute = (binary: string, args: string[], options: RuntimeCommandOptions = {}) => {
        const env = Object.entries(sanitizeContainerEnv(options.env ?? {}))
            .filter(([, value]) => value !== undefined)
            .map(([key, value]) => `${key}=${value}`);
        return command(['exec', '--raw', `--dir=${hostPathToContainerPath(options.cwd ?? pluginRoot)}`, '--',
            'env', ...env, binary, ...args.map(mapCommandArgumentForRuntime)], options);
    };
    return {
        name: 'ddev',
        async setup() {
            const expected = path.join(tempRootBase, runtimeProjectName);
            if (path.resolve(tempRoot) !== expected) {
                throw new Error('Prepared install belongs to a different runtime. Run prepare again.');
            }
            // Reject symlink escapes before resetting any generated files or database.
            for (const dir of [path.join(pluginRoot, '.cache'), path.join(pluginRoot, '.cache/docs-screenshots'), tempRootBase, tempRoot]) {
                if ((await fs.lstat(dir)).isSymbolicLink()) throw new Error(`Symlinked capture runtime: ${dir}`);
            }
            for (const dir of ['.ddev', 'craft-app', '../base-installs']) {
                const target = path.resolve(tempRoot, dir);
                if (await fileExists(target) && (await fs.lstat(target)).isSymbolicLink()) throw new Error(`Symlinked capture path: ${target}`);
            }
            try {
                const handle = await fs.open(lockPath, 'wx');
                await handle.writeFile(String(process.pid));
                await handle.close();
                locked = true;
            } catch {
                throw new Error(`Capture runtime is locked: ${lockPath}. Check for an active capture before removing a stale lock.`);
            }
            const ownerPath = path.join(tempRoot, 'owner.json');
            const owner = JSON.stringify({ pluginRoot: await fs.realpath(pluginRoot), docsRoot: await fs.realpath(docsRoot), project: runtimeProjectName });
            if (await fileExists(ownerPath) && await fs.readFile(ownerPath, 'utf8') !== owner) {
                throw new Error('Capture runtime ownership mismatch. Use a distinct, explicitly named campaign.');
            }
            await fs.writeFile(ownerPath, owner);
            await fs.mkdir(path.join(tempRoot, '.ddev'), { recursive: true });
            await fs.mkdir(path.join(tempRoot, 'craft-app/web'), { recursive: true });
            await fs.writeFile(path.join(tempRoot, '.ddev/config.yaml'), [
                `name: ${runtimeProjectName}`, 'type: php', 'docroot: craft-app/web',
                'php_version: "8.3"', 'database:', '  type: mysql', '  version: "8.0"',
                'composer_version: "2"', 'performance_mode: none', 'timezone: UTC', '',
            ].join('\n'));
            const mounts = [`${pluginRoot}:/plugin`, `${docsRoot}:/capture-docs`, ...captureSources.map(source => `${source.path}:/capture-sources/${source.name}`)];
            await fs.writeFile(path.join(tempRoot, '.ddev/docker-compose.capture.yaml'),
                'services:\n  web:\n    volumes:\n' + mounts.map(mount => `      - ${JSON.stringify(mount)}\n`).join(''));
            await command(['start']);
            started = true;
            const details = JSON.parse(await command(['describe', '--json-output'])).raw;
            if (await fs.realpath(details.approot) !== await fs.realpath(tempRoot)) throw new Error('DDEV capture project belongs to another source directory.');
            return details.httpurl;
        },
        async teardown({ keepRuntime }) {
            try {
                if (started && !keepRuntime) await command(['stop']);
            } finally {
                if (locked) await fs.rm(lockPath, { force: true });
            }
        },
        async prepareCraftInstall({ installDir, pluginMeta, debug }) {
            const sourceDir = await ensurePreparedCraftInstallCache({
                pluginMeta, debug, mapPathForCommand: hostPathToContainerPath,
                pathRepositoryUrl: hostPathToContainerPath(pluginRoot),
                runComposerCommand: (args, options) => execute('composer', args, options),
            });
            await clonePreparedCraftInstall({ sourceDir, installDir });
            // Leave app.php intact: scenario modules configure it using the Craft skeleton.
            for (const kind of ['console', 'web']) {
                await fs.writeFile(path.join(installDir, `config/app.${kind}.php`), "<?php return ['baseApiUrl' => 'http://127.0.0.1:9/'];\n");
            }
        },
        runPhpCommand: (args, options) => execute('php', args, options),
        runComposerCommand: (args, options) => execute('composer', args, options),
        async createDatabase(config, databaseName) {
            await execute('php', ['-r', createDatabasePhp(config, databaseName, true)]);
        },
        async dropDatabase(config, databaseName) {
            await execute('php', ['-r', createDatabasePhp(config, databaseName, true)]);
        },
        async startPhpServer(_installDir, currentBaseUrl) {
            await waitForServerHealth(currentBaseUrl);
            return { async stop() {} };
        },
    };
}

async function prepareCraftInstallWithComposer({
    installDir,
    pluginMeta,
    debug,
    mapPathForCommand,
    pathRepositoryUrl,
    runComposerCommand,
}: {
    installDir: string;
    pluginMeta: { packageName: string; handle: string };
    debug: boolean;
    mapPathForCommand: (targetPath: string) => string;
    pathRepositoryUrl: string;
    runComposerCommand: (args: string[], options?: RuntimeCommandOptions) => Promise<string>;
}): Promise<void> {
    await fs.mkdir(path.dirname(installDir), { recursive: true });
    const installDirForCommand = mapPathForCommand(installDir);

    await runWithRetries(() => runComposerCommand(['create-project', 'craftcms/craft', installDirForCommand, '^5.0', '--no-interaction'], {
        cwd: path.dirname(installDir),
        env: {
            COMPOSER_MEMORY_LIMIT: '-1',
        },
    }), {
        label: 'composer create-project',
        retries: 3,
    });

    const composerJsonPath = path.join(installDir, 'composer.json');
    const composerJson = JSON.parse(await fs.readFile(composerJsonPath, 'utf8')) as Record<string, any>;

    composerJson['minimum-stability'] = 'dev';
    composerJson['prefer-stable'] = true;
    composerJson.repositories = Array.isArray(composerJson.repositories) ? composerJson.repositories : [];
    composerJson.repositories.unshift({
        type: 'path',
        url: pathRepositoryUrl,
        options: {
            symlink: true,
        },
    });

    await fs.writeFile(composerJsonPath, `${JSON.stringify(composerJson, null, 4)}\n`);

    await runWithRetries(() => runComposerCommand(['require', `${pluginMeta.packageName}:*@dev`, '--no-interaction'], {
        cwd: installDir,
        env: {
            COMPOSER_MEMORY_LIMIT: '-1',
        },
    }), {
        label: 'composer require plugin',
        retries: 3,
    });

    if (debug) {
        console.log(`Prepared temp Craft app at ${installDir}`);
    }
}

async function ensurePreparedCraftInstallCache({
    pluginMeta,
    debug,
    mapPathForCommand,
    pathRepositoryUrl,
    runComposerCommand,
}: {
    pluginMeta: { packageName: string; handle: string };
    debug: boolean;
    mapPathForCommand: (targetPath: string) => string;
    pathRepositoryUrl: string;
    runComposerCommand: (args: string[], options?: RuntimeCommandOptions) => Promise<string>;
}): Promise<string> {
    await fs.mkdir(baseInstallCacheRoot, { recursive: true });

    const cacheKey = await createBaseInstallCacheKey(pluginMeta);
    const baseInstallDir = path.join(baseInstallCacheRoot, `${pluginMeta.handle}-${cacheKey}`);
    const readyMarkerPath = path.join(baseInstallDir, '.prepared');
    const autoloadPath = path.join(baseInstallDir, 'vendor', 'autoload.php');

    if (await fileExists(readyMarkerPath) && await fileExists(autoloadPath)) {
        return baseInstallDir;
    }

    const stagingDir = `${baseInstallDir}.staging-${crypto.randomBytes(3).toString('hex')}`;
    await fs.rm(stagingDir, { recursive: true, force: true });
    await fs.mkdir(path.dirname(stagingDir), { recursive: true });

    try {
        await prepareCraftInstallWithComposer({
            installDir: stagingDir,
            pluginMeta,
            debug,
            mapPathForCommand,
            pathRepositoryUrl,
            runComposerCommand,
        });

        await fs.writeFile(readyMarkerPathFor(stagingDir), `${new Date().toISOString()}\n`);
        await fs.rm(baseInstallDir, { recursive: true, force: true });
        await fs.rename(stagingDir, baseInstallDir);
    } catch (error) {
        await fs.rm(stagingDir, { recursive: true, force: true });
        throw error;
    }

    return baseInstallDir;
}

async function createBaseInstallCacheKey(pluginMeta: { packageName: string; handle: string }): Promise<string> {
    const hash = crypto.createHash('sha1');
    const files = [
        path.join(pluginRoot, 'composer.json'),
        path.join(pluginRoot, 'composer.lock'),
        path.join(__dirname, 'cli.ts'),
    ];

    hash.update(`package:${pluginMeta.packageName}\n`);
    hash.update(`handle:${pluginMeta.handle}\n`);
    hash.update(`runtime-version:${screenshotEngineLayoutVersion}\n`);

    for (const filePath of files) {
        if (await fileExists(filePath)) {
            hash.update(filePath);
            hash.update('\n');
            hash.update(await fs.readFile(filePath));
            hash.update('\n');
        }
    }

    return hash.digest('hex').slice(0, 12);
}

function readyMarkerPathFor(installDir: string): string {
    return path.join(installDir, '.prepared');
}

async function clonePreparedCraftInstall({
    sourceDir,
    installDir,
}: {
    sourceDir: string;
    installDir: string;
}): Promise<void> {
    await fs.rm(installDir, { recursive: true, force: true });
    await fs.mkdir(path.dirname(installDir), { recursive: true });
    await fs.cp(sourceDir, installDir, {
        recursive: true,
        dereference: false,
        errorOnExist: false,
        force: true,
        verbatimSymlinks: true,
    });
}

async function fileExists(targetPath: string): Promise<boolean> {
    try {
        await fs.access(targetPath);
        return true;
    } catch (error) {
        if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
            return false;
        }

        throw error;
    }
}

async function runWithRetries<T>(task: () => Promise<T>, options: { label: string; retries?: number; delayMs?: number }): Promise<T> {
    const retries = options.retries ?? 3;
    const delayMs = options.delayMs ?? 2000;
    let lastError: unknown;

    for (let attempt = 1; attempt <= retries; attempt += 1) {
        try {
            return await task();
        } catch (error) {
            lastError = error;

            if (attempt >= retries) {
                break;
            }

            console.log(`${options.label} failed (attempt ${attempt}/${retries}); retrying...`);
            await delay(delayMs * attempt);
        }
    }

    throw lastError;
}

async function waitForServerHealth(baseUrl: string): Promise<void> {
    const healthUrl = new URL('/index.php?p=admin/login', baseUrl).toString();

    for (let attempt = 0; attempt < 50; attempt += 1) {
        try {
            const response = await fetch(healthUrl);
            if (response.ok) {
                return;
            }
        } catch (error) {
            if (attempt === 49) {
                throw error;
            }
        }

        await delay(200);
    }

    const response = await fetch(healthUrl);
    throw new Error(`DDEV web app did not become ready: HTTP ${response.status}; ${(await response.text()).slice(0,500)}`);
}

function hostPathToContainerPath(targetPath: string): string {
    for (const [host, container] of [[pluginRoot, '/plugin'], [docsRoot, '/capture-docs'], ...captureSources.map(source => [source.path, `/capture-sources/${source.name}`])]) {
        const relative = path.relative(host, targetPath);
        if (relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative)) {
            return path.posix.join(container, ...relative.split(path.sep));
        }
    }
    throw new Error(`Capture path is outside the plugin and scenario roots: ${targetPath}`);
}

function shellQuote(value: string): string {
    return `'${value.replace(/'/g, `'\\''`)}'`;
}

function mapCommandArgumentForRuntime(value: string): string {
    if (!path.isAbsolute(value)) {
        return value;
    }

    if (value.startsWith('/plugin/') || value.startsWith('/capture-docs/') || value.startsWith('/var/www/html/') || value.startsWith('/capture-sources/')) {
        return value;
    }

    return hostPathToContainerPath(value);
}

function sanitizeContainerEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
    const sanitized: NodeJS.ProcessEnv = {};

    for (const [key, value] of Object.entries(env)) {
        if (value === undefined) {
            continue;
        }

        if ([
            'TMPDIR',
            'TEMP',
            'TMP',
            'HOME',
            'PATH',
            'PWD',
            'INIT_CWD',
            'npm_config_cache',
            'npm_config_prefix',
            'npm_config_local_prefix',
            'npm_config_global_prefix',
            'npm_package_json',
            'npm_execpath',
            'npm_node_execpath',
            'COMMAND_MODE',
            'SSH_AUTH_SOCK',
            '__CF_USER_TEXT_ENCODING',
            '__CFBundleIdentifier',
        ].includes(key)) {
            continue;
        }

        sanitized[key] = value;
    }

    return sanitized;
}

async function loginToCp(page: Page, baseUrl: string, profile: ScreenshotGlobalProfile): Promise<void> {
    const adminPath = profile.adminPath ?? 'admin';
    const loginUrl = new URL(`/${adminPath}/login`, baseUrl).toString();
    await page.goto(loginUrl, { waitUntil: 'domcontentloaded' });

    const loginForm = page.locator('form.login-form');
    const username = page.locator('input[name="username"], input[name="loginName"]').first();
    const password = page.locator('input[name="password"]');

    await username.waitFor({ state: 'visible' });
    await username.fill(profile.admin.username);
    await password.fill(profile.admin.password);
    await Promise.all([
        page.waitForLoadState('networkidle'),
        loginForm.locator('button[type="submit"]').click(),
    ]);
}

async function applyDeterministicPageStyling(page: Page): Promise<void> {
    // CSS animation/transition timing is one of the easiest ways to introduce
    // screenshot drift between machines. We disable it globally so preview and
    // capture work from a stable, fully-settled visual state.
    await page.addStyleTag({
        content: `
            *,
            *::before,
            *::after {
                animation-duration: 0s !important;
                animation-delay: 0s !important;
                transition-duration: 0s !important;
                transition-delay: 0s !important;
                caret-color: transparent !important;
            }
        `,
    });
}

async function waitForSpec(page: Page, waitFor: WaitForSpec): Promise<void> {
    if (typeof waitFor === 'string') {
        await page.waitForSelector(waitFor, { state: 'visible' });
        return;
    }

    if (waitFor.type === 'selector') {
        await page.waitForSelector(waitFor.selector, {
            state: waitFor.state ?? 'visible',
            timeout: waitFor.timeout,
        });
        return;
    }

    if (waitFor.type === 'timeout') {
        await page.waitForTimeout(waitFor.ms);
        return;
    }

    if (waitFor.type === 'loadState') {
        await page.waitForLoadState(waitFor.state);
        return;
    }

    const locator = waitFor.selector ? page.locator(waitFor.selector) : page.locator('body');
    await locator.getByText(waitFor.text, { exact: false }).filter({ visible: true }).first().waitFor({
        state: 'visible',
        timeout: waitFor.timeout,
    });
}

async function runStep(page: Page, step: ScreenshotStep): Promise<void> {
    // Keep step execution intentionally boring. Plugin-specific behavior should
    // be expressed as higher-level helper factories that emit these primitive
    // steps, which keeps the runtime small and easy to reason about.
    if (step.type === 'click') {
        await page.locator(step.selector).click({ button: step.button });
        return;
    }

    if (step.type === 'fill') {
        await page.locator(step.selector).fill(step.value);
        return;
    }

    if (step.type === 'press') {
        await page.locator(step.selector).press(step.key);
        return;
    }

    if (step.type === 'select') {
        await page.locator(step.selector).selectOption(step.value);
        return;
    }

    if (step.type === 'check') {
        await page.locator(step.selector).check();
        return;
    }

    if (step.type === 'uncheck') {
        await page.locator(step.selector).uncheck();
        return;
    }

    if (step.type === 'wait') {
        await waitForSpec(page, step.waitFor);
        return;
    }

    if (step.type === 'evaluate') {
        await page.evaluate((expression) => {
            // eslint-disable-next-line no-eval
            return eval(expression);
        }, step.expression);
        return;
    }

    if (step.type === 'locatorEvaluate') {
        await page.locator(step.selector).evaluateAll((elements, expression) => {
            // eslint-disable-next-line no-eval
            return eval(expression);
        }, step.expression);
    }
}

async function captureTarget(page: Page, outputPath: string, target?: ScreenshotTarget): Promise<void> {
    // Capture logic mirrors preview overlay logic as closely as possible. That
    // way authors can trust that the red preview box is not "close enough", but
    // genuinely the same region that will be written to disk.
    if (!target || target.type === 'page') {
        await page.screenshot({
            path: outputPath,
            type: 'png',
            scale: 'device',
            fullPage: target?.fullPage ?? true,
        });
        return;
    }

    if (target.type === 'anchoredClip') {
        // Anchored clips deliberately trade convenience for reliability: the
        // crop follows a stable parent element, while still letting a scenario
        // describe a tighter subsection in plain pixel coordinates.
        await stabilizeTargetForMeasurement(page, {
            type: 'selector',
            selector: target.selector,
        });

        const anchorBox = await page.locator(target.selector).first().boundingBox();

        if (!anchorBox) {
            throw new Error(`Unable to capture anchored clip because no bounding box was found for: ${target.selector}`);
        }

        await page.screenshot({
            path: outputPath,
            type: 'png',
            scale: 'device',
            clip: {
                x: Math.max(0, anchorBox.x + target.x),
                y: Math.max(0, anchorBox.y + target.y),
                width: Math.max(1, target.width),
                height: Math.max(1, target.height),
            },
        });
        return;
    }

    if (target.type === 'clip') {
        await page.screenshot({
            path: outputPath,
            type: 'png',
            scale: 'device',
            omitBackground: target.omitBackground === true,
            clip: {
                x: target.x,
                y: target.y,
                width: Math.max(1, target.width),
                height: Math.max(1, target.height),
            },
        });
        return;
    }

    await stabilizeTargetForMeasurement(page, target);

    const locator = page.locator(target.selector);
    const box = await locator.boundingBox();

    if (!box) {
        throw new Error(`Unable to capture selector screenshot because no bounding box was found for: ${target.selector}`);
    }

    const padding = normalizeTargetPadding(target.padding);
    const viewportSize = page.viewportSize();
    const maxWidth = viewportSize?.width ?? Math.ceil(box.x + box.width + padding.right);
    const maxHeight = viewportSize?.height ?? Math.ceil(box.y + box.height + padding.bottom);
    const x = Math.max(0, box.x - padding.left);
    const y = Math.max(0, box.y - padding.top);
    const right = Math.min(maxWidth, box.x + box.width + padding.right);
    const bottom = Math.min(maxHeight, box.y + box.height + padding.bottom);

    await page.screenshot({
        path: outputPath,
        type: 'png',
        scale: 'device',
        // Selector targets may request this for promo crops with transparent padding.
        omitBackground: target.omitBackground === true,
        clip: {
            x,
            y,
            width: Math.max(1, right - x),
            height: Math.max(1, bottom - y),
        },
    });
}

async function showPreviewOverlay(page: Page, target?: ScreenshotTarget): Promise<void> {
    // Preview uses the exact same target math as capture. The overlay exists so
    // authors can tweak scenarios interactively without generating files over
    // and over again.
    const viewportSize = page.viewportSize();

    if (!target || target.type === 'page') {
        await page.evaluate(({ width, height }) => {
            document.querySelectorAll('[data-verbb-docs-screenshot-overlay="true"]').forEach(node => node.remove());

            const overlay = document.createElement('div');
            overlay.dataset.verbbDocsScreenshotOverlay = 'true';
            overlay.style.position = 'fixed';
            overlay.style.left = '0';
            overlay.style.top = '0';
            overlay.style.width = `${width}px`;
            overlay.style.height = `${height}px`;
            overlay.style.border = '2px dashed #e3342f';
            overlay.style.boxSizing = 'border-box';
            overlay.style.pointerEvents = 'none';
            overlay.style.zIndex = '2147483647';
            document.body.appendChild(overlay);
        }, {
            width: viewportSize?.width ?? 0,
            height: viewportSize?.height ?? 0,
        });

        return;
    }

    if (target.type === 'anchoredClip') {
        await stabilizeTargetForMeasurement(page, {
            type: 'selector',
            selector: target.selector,
        });

        const anchorBox = await page.locator(target.selector).first().boundingBox();

        if (!anchorBox) {
            throw new Error(`Unable to preview anchored clip because no bounding box was found for: ${target.selector}`);
        }

        await page.evaluate((clip) => {
            document.querySelectorAll('[data-verbb-docs-screenshot-overlay="true"]').forEach(node => node.remove());

            const overlay = document.createElement('div');
            overlay.dataset.verbbDocsScreenshotOverlay = 'true';
            overlay.style.position = 'fixed';
            overlay.style.left = `${clip.x}px`;
            overlay.style.top = `${clip.y}px`;
            overlay.style.width = `${clip.width}px`;
            overlay.style.height = `${clip.height}px`;
            overlay.style.border = '2px dashed #e3342f';
            overlay.style.background = 'rgba(227, 52, 47, 0.08)';
            overlay.style.boxSizing = 'border-box';
            overlay.style.pointerEvents = 'none';
            overlay.style.zIndex = '2147483647';
            document.body.appendChild(overlay);
        }, {
            x: Math.max(0, anchorBox.x + target.x),
            y: Math.max(0, anchorBox.y + target.y),
            width: Math.max(1, target.width),
            height: Math.max(1, target.height),
        });

        return;
    }

    if (target.type === 'clip') {
        await page.evaluate((clip) => {
            document.querySelectorAll('[data-verbb-docs-screenshot-overlay="true"]').forEach(node => node.remove());

            const overlay = document.createElement('div');
            overlay.dataset.verbbDocsScreenshotOverlay = 'true';
            overlay.style.position = 'fixed';
            overlay.style.left = `${clip.x}px`;
            overlay.style.top = `${clip.y}px`;
            overlay.style.width = `${clip.width}px`;
            overlay.style.height = `${clip.height}px`;
            overlay.style.border = '2px dashed #e3342f';
            overlay.style.background = 'rgba(227, 52, 47, 0.08)';
            overlay.style.boxSizing = 'border-box';
            overlay.style.pointerEvents = 'none';
            overlay.style.zIndex = '2147483647';
            document.body.appendChild(overlay);
        }, {
            x: target.x,
            y: target.y,
            width: Math.max(1, target.width),
            height: Math.max(1, target.height),
        });

        return;
    }

    await stabilizeTargetForMeasurement(page, target);

    const locator = page.locator(target.selector);
    const box = await locator.boundingBox();

    if (!box) {
        throw new Error(`Unable to preview selector target because no bounding box was found for: ${target.selector}`);
    }

    const padding = normalizeTargetPadding(target.padding);
    const maxWidth = viewportSize?.width ?? Math.ceil(box.x + box.width + padding.right);
    const maxHeight = viewportSize?.height ?? Math.ceil(box.y + box.height + padding.bottom);
    const x = Math.max(0, box.x - padding.left);
    const y = Math.max(0, box.y - padding.top);
    const right = Math.min(maxWidth, box.x + box.width + padding.right);
    const bottom = Math.min(maxHeight, box.y + box.height + padding.bottom);

    await page.evaluate((clip) => {
        document.querySelectorAll('[data-verbb-docs-screenshot-overlay="true"]').forEach(node => node.remove());

        const overlay = document.createElement('div');
        overlay.dataset.verbbDocsScreenshotOverlay = 'true';
        overlay.style.position = 'fixed';
        overlay.style.left = `${clip.x}px`;
        overlay.style.top = `${clip.y}px`;
        overlay.style.width = `${clip.width}px`;
        overlay.style.height = `${clip.height}px`;
        overlay.style.border = '2px dashed #e3342f';
        overlay.style.background = 'rgba(227, 52, 47, 0.08)';
        overlay.style.boxSizing = 'border-box';
        overlay.style.pointerEvents = 'none';
        overlay.style.zIndex = '2147483647';
        document.body.appendChild(overlay);
    }, {
        x,
        y,
        width: Math.max(1, right - x),
        height: Math.max(1, bottom - y),
    });
}

async function revealPreviewPage(page: Page): Promise<void> {
    await page.evaluate(() => {
        document.querySelectorAll('[data-verbb-docs-screenshot-preview-mask="true"]').forEach((node) => node.remove());
    });
}

async function stabilizeTargetForMeasurement(page: Page, target?: ScreenshotTarget): Promise<void> {
    if (!target || target.type === 'page' || target.type === 'clip' || target.type === 'anchoredClip') {
        return;
    }

    // Craft/plugin screens frequently render, hydrate, and then adjust scroll
    // containers after first paint. We do a shared stabilization pass before
    // any measurement so selector-based crops do not wander as the page settles.
    const viewportSize = page.viewportSize();
    const viewportWidth = viewportSize?.width ?? 0;
    const viewportHeight = viewportSize?.height ?? 0;
    const locator = page.locator(target.selector).first();

    await page.evaluate((selector) => {
        window.scrollTo(0, 0);
        document.documentElement.scrollTop = 0;
        document.documentElement.scrollLeft = 0;
        document.body.scrollTop = 0;
        document.body.scrollLeft = 0;

        document.querySelectorAll<HTMLElement>('[data-verbb-docs-screenshot-adjusted="true"]').forEach((element) => {
            const originalTransform = element.dataset.verbbDocsScreenshotOriginalTransform;
            const originalTransformOrigin = element.dataset.verbbDocsScreenshotOriginalTransformOrigin;

            if (originalTransform !== undefined) {
                element.style.transform = originalTransform;
            }

            if (originalTransformOrigin !== undefined) {
                element.style.transformOrigin = originalTransformOrigin;
            }

            delete element.dataset.verbbDocsScreenshotAdjusted;
            delete element.dataset.verbbDocsScreenshotOriginalTransform;
            delete element.dataset.verbbDocsScreenshotOriginalTransformOrigin;
        });

        document.querySelectorAll<HTMLElement>('html, body, body *').forEach((element) => {
            element.scrollTop = 0;
            element.scrollLeft = 0;
        });

        const targetElement = document.querySelector(selector);

        if (!(targetElement instanceof HTMLElement)) {
            return;
        }

        let current: HTMLElement | null = targetElement;

        while (current) {
            current.scrollTop = 0;
            current.scrollLeft = 0;
            current = current.parentElement;
        }
    }, target.selector);

    await page.waitForTimeout(80);

    let lastBox: { x: number; y: number; width: number; height: number } | null = null;

    for (let attempt = 0; attempt < 4; attempt += 1) {
        const box = await locator.boundingBox();

        if (!box) {
            return;
        }

        if (lastBox) {
            const stable =
                Math.abs(lastBox.x - box.x) < 1 &&
                Math.abs(lastBox.y - box.y) < 1 &&
                Math.abs(lastBox.width - box.width) < 1 &&
                Math.abs(lastBox.height - box.height) < 1;

            if (stable) {
                break;
            }
        }

        lastBox = box;
        await page.waitForTimeout(60);
    }

    const box = await locator.boundingBox();

    if (!box) {
        return;
    }

    const shiftX = box.x < 0 ? -box.x + 8 : (viewportWidth && box.x + box.width > viewportWidth ? Math.min(0, viewportWidth - (box.x + box.width) - 8) : 0);
    const shiftY = box.y < 0 ? -box.y + 8 : (viewportHeight && box.y + box.height > viewportHeight ? Math.min(0, viewportHeight - (box.y + box.height) - 8) : 0);

    if (Math.abs(shiftX) < 1 && Math.abs(shiftY) < 1) {
        return;
    }

    await locator.evaluate((element, offset) => {
        if (!(element instanceof HTMLElement)) {
            return;
        }

        if (element.dataset.verbbDocsScreenshotOriginalTransform === undefined) {
            element.dataset.verbbDocsScreenshotOriginalTransform = element.style.transform;
        }

        if (element.dataset.verbbDocsScreenshotOriginalTransformOrigin === undefined) {
            element.dataset.verbbDocsScreenshotOriginalTransformOrigin = element.style.transformOrigin;
        }

        const originalTransform = element.dataset.verbbDocsScreenshotOriginalTransform ?? '';
        const trimmedOriginalTransform = originalTransform.trim();
        const translate = `translate(${offset.x}px, ${offset.y}px)`;

        element.style.transform = trimmedOriginalTransform && trimmedOriginalTransform !== 'none'
            ? `${translate} ${trimmedOriginalTransform}`
            : translate;
        element.style.transformOrigin = 'top left';
        element.dataset.verbbDocsScreenshotAdjusted = 'true';
    }, {
        x: shiftX,
        y: shiftY,
    });

    await page.waitForTimeout(80);
}

async function waitForBrowserClose(browser: Browser): Promise<void> {
    if (!browser.isConnected()) {
        return;
    }

    await new Promise<void>((resolve) => {
        browser.once('disconnected', () => resolve());
    });
}

function normalizeTargetPadding(padding?: number | { top?: number; right?: number; bottom?: number; left?: number }) {
    if (typeof padding === 'number') {
        return {
            top: padding,
            right: padding,
            bottom: padding,
            left: padding,
        };
    }

    return {
        top: padding?.top ?? 0,
        right: padding?.right ?? 0,
        bottom: padding?.bottom ?? 0,
        left: padding?.left ?? 0,
    };
}

async function importModule<T>(filePath: string): Promise<T> {
    try {
        await fs.access(filePath);
    } catch (error) {
        const wrappedError = error as NodeJS.ErrnoException;
        wrappedError.code = wrappedError.code ?? 'ENOENT';
        throw wrappedError;
    }

    const imported = await import(pathToFileURL(filePath).href);
    return (imported.default ?? imported) as T;
}

async function runCommand(command: string, args: string[], options: { cwd?: string; allowFailure?: boolean; env?: NodeJS.ProcessEnv } = {}): Promise<string> {
    return new Promise((resolve, reject) => {
        const child = spawn(command, args, {
            cwd: options.cwd,
            env: options.env ?? process.env,
            stdio: ['ignore', 'pipe', 'pipe'],
        });

        let stdout = '';
        let stderr = '';

        child.stdout.on('data', (chunk) => {
            stdout += chunk.toString();
        });

        child.stderr.on('data', (chunk) => {
            stderr += chunk.toString();
        });

        child.on('error', reject);
        child.on('close', (code) => {
            if (code === 0 || options.allowFailure) {
                resolve(stdout.trim());
                return;
            }

            reject(new Error([
                `Command failed: ${command} ${args.join(' ')}`,
                stdout.trim(),
                stderr.trim(),
            ].filter(Boolean).join('\n')));
        });
    });
}

void main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
