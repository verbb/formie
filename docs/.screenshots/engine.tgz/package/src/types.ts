export type ScreenshotViewport = {
    width: number;
    height: number;
    deviceScaleFactor?: number;
};

// Profiles represent the shared Craft/CP baseline for a plugin's docs. Most
// plugins will only need one profile, but keeping it explicit lets us vary
// locale/theme/site-name defaults later without changing every scenario.
export type ScreenshotLogin = {
    username: string;
    password: string;
    email?: string;
};

export type ScreenshotGlobalProfile = {
    id: string;
    siteName: string;
    siteUrl?: string;
    adminPath?: string;
    language?: string;
    timezone?: string;
    locale?: string;
    colorScheme?: 'light' | 'dark';
    viewport: ScreenshotViewport;
    admin: ScreenshotLogin;
};

export type WaitForSelectorSpec = {
    type: 'selector';
    selector: string;
    state?: 'attached' | 'detached' | 'visible' | 'hidden';
    timeout?: number;
};

export type WaitForTimeoutSpec = {
    type: 'timeout';
    ms: number;
};

export type WaitForLoadStateSpec = {
    type: 'loadState';
    state: 'load' | 'domcontentloaded' | 'networkidle';
};

export type WaitForTextSpec = {
    type: 'text';
    text: string;
    selector?: string;
    timeout?: number;
};

export type WaitForSpec =
    | string
    | WaitForSelectorSpec
    | WaitForTimeoutSpec
    | WaitForLoadStateSpec
    | WaitForTextSpec;

// Screenshot steps are intentionally primitive. Higher-level plugin behavior
// should be built by composing these steps in plugin-local presets, rather than
// by teaching the shared package about plugin-specific UI.
export type ClickStep = {
    type: 'click';
    selector: string;
    button?: 'left' | 'right' | 'middle';
};

export type FillStep = {
    type: 'fill';
    selector: string;
    value: string;
};

export type PressStep = {
    type: 'press';
    selector: string;
    key: string;
};

export type SelectStep = {
    type: 'select';
    selector: string;
    value: string | string[];
};

export type CheckStep = {
    type: 'check' | 'uncheck';
    selector: string;
};

export type WaitStep = {
    type: 'wait';
    waitFor: WaitForSpec;
};

export type EvaluateStep = {
    type: 'evaluate';
    expression: string;
};

export type LocatorEvaluateStep = {
    type: 'locatorEvaluate';
    selector: string;
    expression: string;
};

export type ScreenshotStep =
    | ClickStep
    | FillStep
    | PressStep
    | SelectStep
    | CheckStep
    | WaitStep
    | EvaluateStep
    | LocatorEvaluateStep;

export type ScreenshotTarget =
    | {
        type: 'page';
        fullPage?: boolean;
    }
    // `anchoredClip` is the escape hatch for tricky CP screens where a stable
    // DOM node exists but the desired composition is only a subsection of it.
    // Coordinates are measured relative to that selector's bounding box.
    | {
        type: 'anchoredClip';
        selector: string;
        x: number;
        y: number;
        width: number;
        height: number;
    }
    // `clip` is a pure viewport-relative crop. It is most useful during
    // experimentation, but we generally prefer `selector` or `anchoredClip`
    // because they survive small layout shifts better.
    | {
        type: 'clip';
        x: number;
        y: number;
        width: number;
        height: number;
        omitBackground?: boolean;
    }
    | {
        type: 'selector';
        selector: string;
        padding?: number | {
            top?: number;
            right?: number;
            bottom?: number;
            left?: number;
        };
        /** When true, Playwright omits the default page backdrop so CSS-transparent areas stay alpha. */
        omitBackground?: boolean;
    };

export type ScreenshotSetupContext = {
    docsRoot: string;
    pluginRoot: string;
    installDir: string;
    outputRoot: string;
    tempRoot: string;
    baseUrl: string;
    profile: ScreenshotGlobalProfile;
    plugin: {
        packageName: string;
        handle: string;
        className?: string;
    };
    toRuntimePath(targetPath: string): string;
    run(command: string, args?: string[], options?: { cwd?: string; allowFailure?: boolean; env?: NodeJS.ProcessEnv }): Promise<string>;
    runCraft(args: string[], options?: { allowFailure?: boolean; env?: NodeJS.ProcessEnv }): Promise<string>;
    runCraftScript(php: string, options?: { allowFailure?: boolean; label?: string }): Promise<string>;
    installAndEnablePlugin(): Promise<void>;
};

// A scenario is deliberately thin. Anything repeated across multiple
// screenshots should move upward into global profiles, plugin bootstrap, or
// plugin-local presets/helpers instead of growing every scenario file.
export type ScreenshotScenario = {
    id: string;
    output: string;
    route: string | ((context: ScreenshotSetupContext) => Promise<string> | string);
    viewport?: ScreenshotViewport;
    globalProfile?: string;
    loginAs?: Partial<ScreenshotLogin>;
    setup?: (context: ScreenshotSetupContext) => Promise<void> | void;
    preSteps?: ScreenshotStep[];
    steps?: ScreenshotStep[];
    waitFor?: WaitForSpec | WaitForSpec[];
    target?: ScreenshotTarget;
    caption?: string;
    intent?: string;
};

export type ScreenshotPluginBootstrap = {
    id: string;
    setup?: (context: ScreenshotSetupContext) => Promise<void> | void;
};
